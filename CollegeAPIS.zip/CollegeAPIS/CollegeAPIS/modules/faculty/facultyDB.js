var config = require("../../dbconfig");
const sql = require("mssql");

let errorMsg = "";


async function getFaculties() {
  try {
    let pool = await sql.connect(config);
    let faculties = await pool.request().query("SELECT * from Faculty");
    return faculties.recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function getFaculty(facultyId, status, name){
  try {
   let query = "";
   let pool = await sql.connect(config);
   let request = pool.request();

   if (facultyId > 0) {
     request.input("facultyId", sql.Int, facultyId);
     query += " FacultyId = @facultyId";
   }
   if (status > -1) {
     request.input("status", sql.Int, status);
     query += " Status = @status";
   }
   if (name !== "" && name.length > 0) {
     request.input("name", sql.NVarChar, name);
     query += "Name = @name";
   }

   if (query.length < 1) query = "1 = 1";

    let faculty = await pool
      .request()
      .input("input_parameter", sql.Int, facultyId)
      .query("SELECT * from Faculty WHERE FacultyId = @input_parameter");
    return faculty.recordsets;
  } catch (error) {
    console.log(error);
  }
}

async function removeFaculty(facultyId) {
    try {
      let pool = await sql.connect(config);
      let faculty = await pool
        .request()
        .input("input_parameter", sql.Int, facultyId)
        .query("DELETE * from Faculty WHERE FacultyId = @input_parameter");
      return faculty.recordsets;
    } catch (error) {
      console.log(error);
    }
  }

async function addFaculty(faculty) {
  try {
    let pool = await sql.connect(config);
    let insertFaculty = await pool
      .request()
      .input("name", sql.NVarChar, faculty.Name)
      .input("uniqueId", sql.Int, faculty.UniqueID)
      .input("code", sql.NVarChar, faculty.Code)
      .input("status", sql.Int, faculty.Status)
      .execute("InsertFaculty");
    return insertFaculty.recordsets;
  } catch (err) { 
    console.log(err);
  }
}

async function editFaculty(faculty) {
    try {
      let pool = await sql.connect(config);
      let updateFaculty = await pool
        .request()
        .input("facultyId", sql.NVarChar, faculty.FacultyId)
        .input("name", sql.NVarChar, faculty.Name)
        .input("uniqueId", sql.Int, faculty.UniqueID)
        .input("code", sql.NVarChar, faculty.Code)
        .input("status", sql.Int, faculty.Status)
        .execute("UpdateFaculty");
      return updateFaculty.recordsets;
    } catch (err) {
      console.log(err);
    }
  }

module.exports = {
  getFaculties: getFaculties,
  getFaculty: getFaculty,
  removeFaculty: removeFaculty,
  addFaculty: addFaculty,
  editFaculty: editFaculty
};
