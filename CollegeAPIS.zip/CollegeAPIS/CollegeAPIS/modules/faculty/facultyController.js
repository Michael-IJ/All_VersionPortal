var faculty = require("./faculty");
const express = require("express");
const router = express.Router();

class FacultyController {
  constructor(app) {
    router.get("/", faculty.getAllFaculties);
    router.post("/", faculty.getFaculty);
    router.post("/add", faculty.addFaculty);
    router.put("/", faculty.editFaculty);
    router.delete("/:id", faculty.removeFaculty);
    app.use("/api/v1/faculties", router);
  }
}

module.exports = FacultyController;
