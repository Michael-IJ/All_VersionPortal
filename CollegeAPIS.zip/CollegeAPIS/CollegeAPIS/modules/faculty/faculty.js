const db = require("./facultyDB");

class Faculty {
  async getAllFaculties(req, res) {
    console.log("Getting faculties")
    try {
      const retVal = await db.getFaculties();
      if (retVal == null) {
        res.status(400).json({ Error: "No faculties found" });
      }
      res.status(200).send(retVal);
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  async getFaculty(req, res) {
    try {
      const { facultId, status, name } = req.body;
      const retVal = await db.getFaculties(facultId, status, name);
      if (retVal == null) {
        res
          .status(400)
          .json({
            Error: db.getError() === null ? "No faculty found" : db.getError(),
          });
      }
      res.status(200).send(retVal);
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  async addFaculty(req, res) {
    try {
      const faculty = { ...req.body };

      //----------------------Validate API HERE ----------------------------------
      if (faculty.Name === "" || faculty.Name.length < 3) {
        res.status(400).json({ Error: "Invalid/Empty faculty name" });
      } else if (faculty.UniqueId === "") {
        res.status(400).json({ Error: "Invalid UniqueId" });
      } else if (faculty.Code === "") {
        res.status(400).json({ Error: "Invalid code" });
      } else if (faculty.Status === 0) {
        res.status(400).json({ Error: "Invalid status" });
      }
      await db.addFaculty(faculty);
      res.status(200).json({ IsSuccess: true });
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  async removeFaculty(req, res) {
    try {
      const faculty = { ...req.body };
      if (faculty.FacultyId == 0) {
        res.status(400).json({ Error: "Please input a valid faculty Id" });
      }
      console.log(faculty.FacultyId);
      await db.removeFaculty(faculty.FacultyId);
      res.status(200).json({ IsSuccessFul: true });
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  async editFaculty(res, req) {
    try {
      const faculty = { ...req.body };
      if (faculty.Name === "" || faculty.Name.length < 3) {
        res.status(400).json({ Error: "Invalid/Empty faculty Name" });
      }
      await db.editfaculty(faculty);
      res.status(200).json({ IsSuccessFul: true });
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }
}

module.exports = new Faculty;
