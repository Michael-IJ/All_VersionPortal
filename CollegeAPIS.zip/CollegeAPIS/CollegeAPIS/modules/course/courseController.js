var course = require("./course");
const express = require("express");
const router = express.Router();

class CourseController{
    constructor(app){
        router.get("/", course.getAllCourses);
        router.post("/", course.getCourses);
        router.post("/add", course.addCourse);
        router.put("/", course.editCourse);
        router.delete("/:id", course.removeCourse);
        app.use("/api/v1/courses", router);
    }
}

module.exports = CourseController;