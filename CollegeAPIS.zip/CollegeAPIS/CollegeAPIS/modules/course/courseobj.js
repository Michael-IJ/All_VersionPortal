class CourseObj{
    constructor(){
        this.CourseId = 0;
        this.DepartmentId = 0;
        this.Name = "";
        this.UniqueID = "";
        this.Units = 0;
        this.Code = "";
        this.CourseLevel = 0;
        this.CourseSemester = 0;
        this.Status = 0;
    }
}

class CourseFilterObj{
    constructor(){
        this.DepartmentId = 0;
        this.Name = "";
        this.Status = 0;
    }
}