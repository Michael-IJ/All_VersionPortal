const db = require("./courseDB");

class Course{
    async getAllCourses(req, res){
        try{
            const retVal = await db.getAllCourses();
            if(retVal == null){
                res.status(400).json({Error: "DB Response Was Null"});
            }
            res.status(200).send(retVal);
        } catch(error){
            res.status(400).json({Error: error});
            console.log(error);
        }
    }

    async getCourses(req, res){
        try{
            const { deptId, status, name } = req.body;
            const retVal = await db.getCourses(deptId, status, name);
            if(retVal == null){
                res.status(400).json({Error: db.getError() === null ? "DB Response Was Null" : db.getError()});
            }
            res.status(200).send(retVal);
        } catch(error){
            res.status(400).json({ Error: error});
            console.log(error);
        }
    }

    async addCourse(req, res){
        try{
            const course = { ... req.body };
            //Validate Api here
            if(course.Name === "" || course.Name.length < 3){
                res.status(400).json({ Error: "Invalid/Empty Course Name"});
            }
            else if(course.DepartmentId == 0){
                res.status(400).json({Error: "Invalid Department Id"});
            }
            else if(course.UniqueID == ""){
                res.status(400).json({ Error: "Invalid Unique Id"})
            }
            else if(course.Code == ""){
                res.status(400).json({Error: "Invalid Code"});
            }
            else if(course.CourseLevel == 0){
                res.status(400).json({Error: "Invalid Course Level"});
            }
            else if(course.CourseSemester == 0){
                res.status(400).json({ Error: "Invalid Course Semester"})
            }
            else if(course.Status == 0){
                res.status(400).json({ Error: "Invalid Status"})
            }
            await db.addCourse(course);
            res.status(200).json({ IsSuccessFul: true})
        } catch(error){
            res.status(400).json({ Error: error});
            console.log(error);
        }
    }

    async removeCourse(req, res){
        try{
            if(!(req.params.id)){
                res.status(400).json({ Error: "Please input a valid course Id" });           
            }
                await db.removeCourse(req.params.id)
            res.status(200).json({ IsSuccessFul: true });
        } catch(error){
            res.status(400).json({ Error: error});
            console.log(error);
        }
    }

    async editCourse(req, res){
        try{
            const course = { ... req.body };
            if(course.Name === "" || course.Name.length < 3){
                res.status(400).json({ Error: "Invalid/Empty Course Name"})
            }
            await db.editCourse(course);       
            res.status(200).json({ IsSuccessFul: true});
        } catch(error){
            res.status(400).json({ Error: error})
            console.log(error);
        }
    }
}

module.exports = new Course;