var config = require("../../dbconfig");
const sql = require("mssql");

let errorMsg = "";

async function getAllCourses() {
  try {
    let pool = await sql.connect(config);
    let courses = await pool.request().query("SELECT * from Course");
    return courses.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
  }
}

async function getCourses(deptId, status, name) {
  try {
    let query = "";
    let pool = await sql.connect(config);
    let request = pool.request();

    if(deptId > 0){
      request.input("departmentId", sql.Int, deptId);
      query += " DepartmentId = @departmentId";
    }
    if(status > -1){
      request.input("status", sql.Int, status);
      query += " Status = @status";
    }
    if(name !== "" && name.length > 0){
      request.input("name", sql.NVarChar, name);
      query += "Name = @name";
    }

    if(query.length < 1) query = "1 = 1";

    let course = await pool
      .request()
      .query("SELECT * from Course where CourseId = @input_parameter " + query);
    return course.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
  }
}


//CourseFilterObj
async function getCourse(courseId){
  try{
    let pool = await sql.connect(config);
    let course = await pool
    .request()
    .input("input_parameter", sql.Int, courseId)
    .query("SELECT * FROM Course where CourseId = @input_parameter");
    return course.recordsets;
  } catch(error){
    console.log(error);
  }
}

async function removeCourse(courseId) {
    try {
      let pool = await sql.connect(config);
      let deleteCourse = await pool
        .request()
        .input("input_parameter", sql.Int, courseId)
        .query("DELETE from Course where courseId = @input_parameter");
      return deleteCourse.recordsets;
    } catch (error) {
      errorMsg = error;
      console.log(error);
    }
  }

async function addCourse(course) {
  try {
    let pool = await sql.connect(config);
    let insertCourse = await pool
      .request()
      .input("departmentId", sql.Int, course.DepartmentId)
      .input("name", sql.NVarChar, course.Name)
      .input("uniqueId", sql.NChar, course.UniqueID)
      .input("units", sql.Int, course.Units)
      .input("code", sql.NChar, course.Code)
      .input("courseLevel", sql.Int, course.CourseLevel)
      .input("courseSemester", sql.Int, course.CourseSemester)
      .input("status", sql.Int, course.Status)
      .execute("InsertCourse");
    return insertCourse.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
  }
}


async function editCourse(course) {
    try {
      let pool = await sql.connect(config);
      let updateCourse = await pool
        .request()
        .input("courseId", sql.Int, course.CourseId)
        .input("departmentId", sql.Int, course.DepartmentId)
        .input("name", sql.NVarChar, course.Name)
        .input("uniqueId", sql.NChar, course.UniqueID)
        .input("units", sql.Int, course.Units)
        .input("code", sql.NChar, course.Code)
        .input("courseLevel", sql.Int, course.CourseLevel)
        .input("courseSemester", sql.Int, course.CourseSemester)
        .input("status", sql.Int, course.Status)
        .execute("UpdateCourse");
      return updateCourse.recordsets;
    } catch (error) {
      errorMsg = error;
      console.log(error);
    }
  }

  function getError(){
    return errorMsg;
  }


module.exports = {
    getAllCourses: getAllCourses,
    getCourses: getCourses,
    getCourse: getCourse,
    removeCourse: removeCourse,
    addCourse: addCourse,
    editCourse: editCourse,
    getError: getError
};
