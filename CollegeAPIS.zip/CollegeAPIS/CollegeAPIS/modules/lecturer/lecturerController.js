var lecturer = require("./lecturer");
const express = require("express");
const router = express.Router();

class LecturerController{
    constructor(app){
        router.get("/", lecturer.getAllLecturers);
        router.post("/", lecturer.getLecturers);
        router.post("/add", lecturer.addLecturers);
        router.delete("/:id", lecturer.removeLecturer)
        app.use("/api/v1/lecturers", router);
    }
}

module.exports = LecturerController;