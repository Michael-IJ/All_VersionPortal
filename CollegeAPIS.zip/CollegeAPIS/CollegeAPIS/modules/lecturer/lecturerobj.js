class LecturerObj{
    constructor(){
        this.LecturerId = 0,
        this.DepartmentId = 0,
        this.Surname = "",
        this.FirstName = "",
        this.OtherName = "",
        this.StaffId = "",
        this.Status = 0
    }
}

class LecturerFilterObj{
    constructor(){
        this.DepartmentId = 0,
        this.StaffId = "",
        this.Status = 0
    }
}