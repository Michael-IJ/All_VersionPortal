var config = require("../../dbconfig");
const sql = require("mssql");

let errorMsg = "";

async function getAllLecturers() {
  try {
    let pool = await sql.connect(config);
    let lecturers = await pool.request().query("SELECT * from Lecturer");
    return lecturers.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
  }
}

async function getLecturers(deptId, status, staffId, lecturerId) {
  try {
    let query = "";
    let pool = await sql.connect(config);
    let request = pool.request();

    if(deptId > 0){
      request.input("departmentId", sql.Int, deptId);
      query += " DepartmentId = @departmentId";
    }
    if (status > -1){
      request.input("status", sq.Int, status);
      query += "Name = @name";
    }
    if(staffId !== "" && staffId.length > 0){
      request.input("staffId", sql.NChar, staffId);
      query += "StaffId = @staffId";
    }

    if(query.length < 1) query = "1 = 1";

    let lecturer = await pool
      .request()
      .input("input_parameter", sql.Int, lecturerId)
      .query("SELECT * from Lecturer WHERE LecturerId = @input_parameter");
    return lecturer.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
  }
}

async function removeLecturer(lecturerId) {
    try {
      let pool = await sql.connect(config);
      let lecturer = await pool
        .request()
        .input("input_parameter", sql.Int, lecturerId)
        .query("DELETE from Lecturer WHERE LecturerId = @input_parameter");
      return lecturer.recordsets;
    } catch (error) {
      errorMsg = error;
      console.log(error);
    }
  }

async function addLecturers(lecturer) {
  try {
    let pool = await sql.connect(config);
    console.log(pool);
    let insertLecturer = await pool
      .request()
      .input("departmentId", sql.NChar, lecturer.DepartmentId)
      .input("surname", sql.NVarChar, lecturer.Surname)  
      .input("firstName", sql.NVarChar, lecturer.FirstName)
      .input("otherName", sql.NVarChar, lecturer.OtherName)
      .input("staffId", sql.Int, lecturer.StaffId)
      .input("status", sql.Int, lecturer.Status)
      .execute("InsertLecturer");
    return insertLecturer.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
  }
}

async function editLecturer(lecturer) {
    try {
      let pool = await sql.connect(config);
      let updateLecturer = await pool
        .request()
        .input("lecturerId", sql.Int, lecturer.LecturerId)
        .input("departmentId", sql.NChar, lecturer.DepartmentId)
        .input("surname", sql.NVarChar, lecturer.Surname)  
        .input("firstName", sql.NVarChar, lecturer.FirstName)
        .input("otherName", sql.NVarChar, lecturer.OtherName)
        .input("staffId", sql.Int, lecturer.StaffId)
        .input("status", sql.Int, lecturer.Status)
        .execute("UpdateLecturer");
      return updateLecturer.recordsets;
    } catch (error) {
      errorMsg = error;
      console.log(error);
    }
  }

  function getError(){
    return errorMsg;
  }

module.exports = {
    getAllLecturers: getAllLecturers,
    getLecturers: getLecturers,
    removeLecturer: removeLecturer,
    addLecturers: addLecturers,
    editLecturer: editLecturer,
    getError: getError
};

