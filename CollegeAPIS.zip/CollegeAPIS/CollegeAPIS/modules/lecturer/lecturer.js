const db = require("./lecturerDB");

class Lecturer{
    async getAllLecturers(req, res){
        try{
            const retVal = await db.getAllLecturers();
            if(retVal == null){
                res.status(400).json({Error: "DB Response Was Null" });
            }
            res.status(200).send(retVal);
        } catch(error){
            res.status(400).json({ Error: error });
            console.log(error);
        }
    }

    async getLecturers(req, res){
        try{
            const { deptId, status, staffId } = req.body;
            const retVal = await db.getLecturers(deptId, status, staffId, lecturerId);
            if(retVal == null){
                res.status(400).json({
                    Error: db.getError() === null ? "DB Response was Null" : db.getError() 
                });
                res.status(200).send(retVal);
            }
        } catch(error){
            res.status(400).json({Error: error});
            console.log(error);
        }
    }

    async addLecturers(req, res){
        try{
            const lecturer = { ...req.body }
            if(lecturer.SurName === "" || lecturer.SurName < 3){
                res.status(400).json({ Error: "Invalid / Empty SurName"})
            }
            await db.addLecturers(lecturer);
            res.status(200).json({ IsSuccessFul: true });
        } catch(error){
            res.status(400).json({Error: error});
            console.log(error);
        }
    }

    async removeLecturer(req, res){
        try{
            if(!(req.params.id)){
                res.status(400).json({ Error: "Please input a valid lecturer Id"})
            }
                await db.removeLecturer(req.params.id);
        } catch(error){
            res.status(400).json({ Error: error});
            console.log(error);
        }
    }

    async editLecturer(req, res){
        try{
            const lecturer = { ...req.body };
            if(lecturer.SurName === "" || lecturer.SurName.length < 3){
                res.status(400).json({ Error: "Invalid/Emoty Course Name"});
            }
            await db.editLecturer(lecturer);
            res.status(200).json({ IsSuccessful: true})
        } catch(error){
            res.status(400).json({ Error: error });
            console.log(error)
        }
    }

}

module.exports = new Lecturer();