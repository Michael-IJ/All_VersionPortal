class CourseOfStudy{
    constructor(
        courseOfStudyId,
        departmentId,
        name,
        shortName,
        uniqueId,
        award,
        duration,
        requiredCreditUnits,
        advisor,
        status
    ){
        this.CourseOfStudyId = courseOfStudyId;
        this.DepartmentId = DepartmentId;
        this.Name = name;
        this.ShortName = shortName;
        this.UniqueID = uniqueId;
        this.Award = award;
        this.Duration = duration;
        this.RequiredCreditUnits = requiredCreditUnits;
        this.Advisor = advisor;
        this.Status = status;
        
    }
}