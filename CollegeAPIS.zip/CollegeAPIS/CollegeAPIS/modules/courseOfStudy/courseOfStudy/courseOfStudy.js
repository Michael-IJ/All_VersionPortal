const db = require('./courseOfStudyDB')

class CourseOfStudy {
    async getAllCourseOfStudies(req, res) {
        try {
            const retVal = await db.getAllCourseOfStudies();
            if (retVal == null) {
                res.status(400).json({ Error: "DB Response Was Null" });
            }
            res.status(200).send(retVal);
        } catch (error) {
            res.status(500).json({ Error: error })
            console.log(error);
        }
    }

    async getCourseOfStudies(req, res) {
        try {
            const { deptId, status, name } = req.body;
            const retVal = await db.getCourseOfStudies(deptId, status, name);
            if (retVal == null) {
                res.status(400).json({ Error: db.getError() === null ? "DB Response Was Null" : db.getError() });
            }
            res.status(200).send(retVal);
        } catch (error) {
            res.status(400).json({ Error: error });
            console.log(error);
        }
    }

    async getCourseOfStudy(req, res){
        try{
            const  CourseOfStudyId =  req.params.id;
            const retVal = await db.getCourseOfStudy(CourseOfStudyId);
            if(retVal == null){
                res.status(400).json({Error: "DB Response Was Null"});
            }
            res.status(200).send(retVal);
        } catch(error){
            res.status(400).json({Error: error});
            console.log(error);
        }
    }

    async addCourseOfStudy(req, res){
        try{
            const CourseOfStudy = { ... req.body };
            console.log(CourseOfStudy);
            //Validate Api here
            const validate = validator(CourseOfStudy);
            if(validate.length > 1){
                res.status(400).json({ Error: validate});
            }
            if(!await db.addCourseOfStudy(CourseOfStudy)){
                return res.status(400).json({ Error: db.getError() })
            } 
            res.status(200).json({ IsSuccessFul: true})
        } catch(error){
            res.status(400).json({ Error: error});
            console.log(error);
        }
    }

    // async createCourseOfStudy(req, res) {
    //     try {
    //         const newCourseOfStudy = await db.addCourseOfStudy(req.body)
    //         res.status(201).json(newCourseOfStudy)
    //     }
    //     catch (error) {
    //         res.status(500).json({ message: error.message })
    //     }

    // }

    async removeCourseOfStudy(req, res){
        try{
            if(!(req.params.id)){
                res.status(400).json({ Error: "Please input a valid course Id" });           
            }
                await db.removeCourseOfStudy(req.params.id)
            res.status(200).json({ IsSuccessFul: true });
        } catch(error){
            res.status(400).json({ Error: error});
            console.log(error);
        }
    }

    async editCourseOfStudy(req, res){
        try{
            const CourseOfStudy = { ... req.body };
            if(CourseOfStudy.CourseOfStudyId < 1){
                return res.status(400).json({ Error: "CourseOfStudy Id is required"});
            }
            const validate = validator(course);
            if(validate.length > 1){
                res.status(400).json({ Error: validate});
            }
            if(!await db.editCourseOfStudy(course)){
                return res.status(400).json({ Error: db.getError() })
            }      
            res.status(200).json({ IsSuccessFul: true});
        } catch(error){
            res.status(400).json({ Error: error})
            console.log(error);
        }
    }
}

const validator = (CourseOfStudy) => {
    if(CourseOfStudy.Name === "" || CourseOfStudy.Name.length < 3){
        return "Invalid/Empty CourseOfStudy Name";
    }
    if(CourseOfStudy.DepartmentId < 1){
        return "Invalid Department Id";
    }
    if(CourseOfStudy.UniqueID == "" || CourseOfStudy.UniqueID?.length < 4){
        return "Invalid Unique Id";
    }
    if(CourseOfStudy.Award < 1){
        return "Invalid Award";
    }
    if(CourseOfStudy.Duration == 0){
        return "Invalid Duration";
    }
    if(CourseOfStudy.RequiredCreditUnits < 1){
        return "Invalid Award";
    }
    if(CourseOfStudy.Advisor == 0){
        return "Invalid Status";
    }
    if(CourseOfStudy.Status == 0){
        return "Invalid Status";
    }
    return "";
}

module.exports = new CourseOfStudy()