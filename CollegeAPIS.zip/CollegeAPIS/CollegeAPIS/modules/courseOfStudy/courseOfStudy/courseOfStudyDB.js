var config = require("../../dbconfig");
const sql = require("mssql");

let errorMsg = "";

async function getAllCourseOfStudies() {
  try {
    // let pool = await sql.connect(config);
    // let courseOfStudies = await pool.request().query("SELECT * from CourseOfStudy");
    let pool = await sql.connect(config);
    let courseOfStudies = await pool.request().query("SELECT * from CourseOfStudy");
   let retVal =  courseOfStudies ?? {};
   return retVal.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
    return null
  }
}

async function getCourseOfStudies(deptId, status, name) {
  try {
    let query = "";
    let pool = await sql.connect(config);
    let request = pool.request();

    if (deptId > 0) {
      request.input("departmentId", sql.Int, deptId);
      query += " DepartmentId = @departmentId";
    }
    if (status > -1) {
      request.input("status", sql.Int, status);
      query += query.length > 1 ? " AND Status = @status" : " Status = @status";
    }
    if (name !== "" && name.length > 0) {
      request.input("name", sql.NVarChar, name);
      query += query.length > 1 ? " AND Name = @name" : " Name = @name";
    }

    if (query.length < 1) query = "1 = 1";

    let courseOfStudy = await request.query("SELECT * from CourseOfStudy where " + query)
    let retVal =  courseOfStudy ?? {};
   return retVal.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
    return -1
  }
}

// async function getCourseOfStudies() {
//   try {
//     let pool = await sql.connect(config);
//     let courseOfStudy = await pool.request().query("SELECT * from CourseOfStudy");
//     return courseOfStudy.recordsets;
//   } catch (error) {
//     console.log(error);
//   }
// }

async function getCourseOfStudy(courseOfStudyId) {
  try {
    let pool = await sql.connect(config);
    let courseOfStudy = await pool
      .request()
      .input("input_parameter", sql.Int, courseOfStudyId)
      .query("SELECT * from CourseOfStudy WHERE courseOfStudyId = @input_parameter");
    let retVal =  courseOfStudy ?? {};
   return retVal.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
    return -1
  }
}

async function removeCourseOfStudy(courseOfStudyId) {
  try {
    let pool = await sql.connect(config);
    let deleteCourseOfStudy = await pool
      .request()
      .input("input_parameter", sql.Int, courseOfStudyId)
      .query("DELETE * from CourseOfStudy WHERE courseOfStudyId = @input_parameter");
     let retVal =  deleteCourseOfStudy ?? {};
   return retVal.recordsets;
  } catch (error) {
    errorMsg = error;
    console.log(error);
    return -1
    
  }
}

async function addCourseOfStudy(courseOfStudy) {
  try {
    let pool = await sql.connect(config);
    let insertCourseOfStudy = await pool
      .request()
      .input("departmentId", sql.Int, courseOfStudy.DepartmentId)
      .input("name", sql.NVarChar, courseOfStudy.Name)
      .input("shortName", sql.NChar, courseOfStudy.ShortName)
      .input("uniqueID", sql.NChar, courseOfStudy.UniqueID)
      .input("award", sql.NVarChar, courseOfStudy.Award)
      .input("duration", sql.Int, courseOfStudy.Duration)
      .input("requiredCreditUnits", sql.Int, courseOfStudy.RequiredCreditUnits)
      .input("advisor", sql.NVarChar, courseOfStudy.Advisor)
      .input("status", sql.Int, courseOfStudy.Status)
      .execute("InsertCourseOfStudy");
     let retVal = insertCourseOfStudy ?? {};
     retVal = retVal.rowsAffected.length;
    // console.log(retVal);
    if (!retVal || retVal < 1 ) {
      errorMsg = "No Insert Was Performed " + retVal;
      return false;
    }

    return true;
  } catch (error) {
    errorMsg = error;
    console.log(error);
    return -1
  }
}

async function editCourseOfStudy(courseOfStudy) {
  try {
    let pool = await sql.connect(config);
    let updateCourseOfStudy = await pool
      .request()
      .input("courseOfStudyId", sql.Int, courseOfStudy.CourseOfStudyId)
      .input("departmentId", sql.Int, courseOfStudy.DepartmentId)
      .input("name", sql.NVarChar, courseOfStudy.Name)
      .input("shortName", sql.NChar, courseOfStudy.ShortName)
      .input("uniqueId", sql.NChar, courseOfStudy.UniqueId)
      .input("award", sql.NVarChar, courseOfStudy.Award)
      .input("duration", sql.Int, faculty.Duration)
      .input("requiredCreditUnits", sql.Int, courseOfStudy.RequiredCreditUnits)
      .input("advisor", sql.NVarChar, courseOfStudy.Code)
      .input("status", sql.Int, courseOfStudy.Status)
      .execute("UpdateCourse");
    let retVal = updateCourseOfStudy ?? {};
     retVal = retVal.rowsAffected.length;
    // console.log(retVal);
    if (!retVal || retVal < 1 ) {
      errorMsg = "No Update Was Performed " + retVal;
      return false;
    }

    return true;

  } catch (error) {
    errorMsg = error;
    console.log(error);
    return -1;
  }
}
function getError() {
  return errorMsg;
}

module.exports = {
  getAllCourseOfStudies: getAllCourseOfStudies,
  getCourseOfStudies: getCourseOfStudies,
  getCourseOfStudy: getCourseOfStudy,
  removeCourseOfStudy: removeCourseOfStudy,
  addCourseOfStudy: addCourseOfStudy,
  editCourseOfStudy: editCourseOfStudy,
  getError: getError
};