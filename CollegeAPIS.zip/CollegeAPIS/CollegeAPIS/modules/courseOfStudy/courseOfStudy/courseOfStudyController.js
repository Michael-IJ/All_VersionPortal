var courseOfStudy = require("./courseOfStudy");
const router = require("express").Router();

class CourseOfStudyController{
    constructor(app){
        router.get("/", courseOfStudy.getAllCourseOfStudies);
        router.post("/", courseOfStudy.getCourseOfStudies);
        router.get("/:id", courseOfStudy.getCourseOfStudy);
        router.post("/add", courseOfStudy.addCourseOfStudy);
        router.put("/", courseOfStudy.editCourseOfStudy);
        router.delete("/:id", courseOfStudy.removeCourseOfStudy);
        app.use("/api/v1/courseOfStudy", router);
    }
}

module.exports = CourseOfStudyController;