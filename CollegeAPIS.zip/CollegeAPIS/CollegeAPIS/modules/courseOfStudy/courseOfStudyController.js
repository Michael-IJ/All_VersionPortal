var course = require("./courseOfStudy");
const router = require("express").Router();

class CourseOfStudyController{
    constructor(app){
        router.get("/", course.getCourseOfStudies);
        router.post("/", course.getCourseOfSTudy);
        router.post("/add", course.createCourseOfStudy);
        router.put("/", course.updateCourseOfStudy);
        router.delete("/:id", course.deleteCourseOfStudy);
        app.use("/api/v1/courseOfStudy", router);
    }
}

module.exports = CourseOfStudyController;