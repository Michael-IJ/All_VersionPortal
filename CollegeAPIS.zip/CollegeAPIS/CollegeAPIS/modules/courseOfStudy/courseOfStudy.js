const db = require('./courseOfStudyDB')

class CourseOfStudy {

    async getCourseOfStudies(req, res) {
        try {
            const courseOfStudy = await db.getCourseOfStudies()
            res.json(courseOfStudy)
        } catch (error) {
            res.status(500).json({ message: error.message })
        }
    }

    async getCourseOfStudy(req, res) {
        try {
            const courseOfStudy = await db.getCourseOfStudy(req.params.id)
            res.json(courseOfStudy)
        } catch (error) {
            res.status(500).json({ message: error.message })
        }
    }

    async createCourseOfStudy(req, res) {
        try {
            const newCourseOfStudy = await db.addCourseOfStudy(req.body)
            res.status(201).json(newCourseOfStudy)
        }
        catch (error) {
            res.status(500).json({ message: error.message })
        }

    }

    
    async updateCourseOfStudy(req, res) {
        try {
            const updatedCourseOfStudy = await db.editCourseOfStudy(req.params.id, req.body)
            res.json(updatedCourseOfStudy)
        }
        catch (error) {
            res.status(500).json({ message: error.message })
        }
    }

    async deleteCourseOfStudy(req, res) {
        try {
            const deletedCourseOfStudy = await db.removeCourseOfStudy(req.params.id)
            res.json(deletedCourseOfStudy)
        }       
        catch (error) {
            res.status(500).json({ message: error.message })
        }
    }

}

module.exports = new CourseOfStudy()