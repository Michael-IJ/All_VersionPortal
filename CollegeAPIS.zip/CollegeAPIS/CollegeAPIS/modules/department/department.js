const db = require("./departmentDB");

class Course {
  async getAllDepartments(req, res) {
    try {
      const retVal = await db.getDepartments();
      if (retVal == null) {
        res.status(400).json({ Error: "DB Response Was Null" });
      }
      res.status(200).send(retVal);
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  async getDepartment(req, res) {
    try {
      const { deptId, status, name } = req.body;
      const retVal = await db.getDepartment(deptId, status, name);
      if (retVal == null) {
        res.status(400).json({
          Error:
            db.getError() === null ? "DB Response Was Null" : db.getError(),
        });
      }
      res.status(200).send(retVal);
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  async addDepartment(req, res) {
    try {
      const department = { ...req.body };
      //Validate Api here
      if (department.Name === "" || department.Name.length < 3) {
        res.status(400).json({ Error: "Invalid/Empty Department Name" });
      } else if (department.DepartmentId == "") {
        res.status(400).json({ Error: "Invalid Department Id" });
      } else if (department.FacultyId == "") {
        res.status(400).json({ Error: "Invalid Faculty Id" });
      } else if (department.UniqueID == "") {
        res.status(400).json({ Error: "Invalid Unique Id" });
      } else if (course.Code == "") {
        res.status(400).json({ Error: "Invalid Code" });
      } else if (course.Status == 0) {
        res.status(400).json({ Error: "Invalid Status" });
      }
      await db.addDepartment(course);
      res.status(200).json({ IsSuccessFul: true });
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  async removeDepartment(req, res) {
    try {
        const department = { ...req.body }
            if(department.DepartmentId == 0){
                res.status(400).json({ Error: "Please input a valid course Id" });
            }
            console.log(department.DepartmentId);
            await db.removeDepartment(department.DepartmentId)
            res.status(200).json({ IsSuccessFul: true });
    } catch (error) {
        res.status(400).json({ Error: error});
            console.log(error);
    }
  }

  async editDepartment(res, req){
    try{
        const department = { ... req.body };
        if(department.Name === "" || department.Name.length < 3){
            res.status(400).json({ Error: "Invalid/Empty Department Name"})
        }
        await db.editDepartment(department);
        res.status(200).json({ IsSuccessFul: true});
    } catch(error){
        res.status(400).json({ Error: error})
        console.log(error);
    }
}
}

module.exports = new Course();
