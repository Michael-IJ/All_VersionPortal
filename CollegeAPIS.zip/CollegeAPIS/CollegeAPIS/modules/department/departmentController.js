var department = require("./department");
const express = require("express");
const router = express.Router();

class DepartmentController{
    constructor(app){
        router.get("/", department.getAllDepartments);
        router.post("/", department.getDepartment);
        router.post("/add", department.addDepartment);
        app.use("/api/v1/departments", router);
    }
}

module.exports = DepartmentController;