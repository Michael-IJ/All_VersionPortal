class DepartmentObj {
  constructor() {
    this.DepartmentId = 0;
    this.FacultyId = 0;
    this.Name = "";
    this.UniqueID = "";
    this.Code = "";
    this.Status = 0;
  }
}

class DepartmentFilterObj {
  constructor() {
    this.DepartmentId = 0;
    this.Name = "";
    this.Status = 0;
  }
}
