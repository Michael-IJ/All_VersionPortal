const addForms = document.getElementById("addForms");
const editForms = document.getElementById("editForms");
const detailForm = document.getElementById("detailForms");
const table = document.getElementById("table-body");
const API_Url = "http://192.168.17.220:8097";
const errDiv = document.createElement("div");
errDiv.className = "alert alert-danger";
const validate = new Validate();
let data;
let deptData;
let lecturerId;


const lecture = async () => {
  try {
    const response = await axios.get(`${API_Url}/api/v1/lecturers`);
    data = response.data;

    const res = await axios.get(`${API_Url}/api/v1/departments`);
   deptData = res.data;

    const departmentSelect = document.querySelector("#departmentId");

    let deptMap = deptData.map((item, index) => {
      return `<option value="${item.DepartmentId}">${item.Name}</option>`;
    });
    let allData = `<option value="">--Please-Select---</option>`;
    departmentSelect.innerHTML = allData + deptMap.join("");

    data.forEach((lecturer, id) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${id + 1}</td>
        <td>${lecturer.Surname}</td>
        <td>${lecturer.StaffId}</td>
        <td>${
          lecturer.Status == 1
            ? '<div class="text-success">Active</div>'
            : '<div class="text-danger">Inactive<div>'
        }</td>
        <td>
          <button class="btn btn-success" data-toggle="modal" data-target="#editModal" aria-label="Close" onclick="editLecturer(${
            lecturer.LecturerId
          })">Edit</button>
          <button class="btn btn-danger" onclick="deleteLecturer(${
            lecturer.LecturerId
          })">Delete</button>
           <button class="btn btn-success" data-toggle="modal" data-target="#detailModal" aria-label="Close" onclick="detailLecturer(${
             lecturer.LecturerId
           })">Details</button>
        </td>
      `;
      table.appendChild(row);
    });
  } catch (error) {
    console.log(error);
  }
};

document.addEventListener("DOMContentLoaded", lecture);

// Getting Input from the Html //
const departmentId = document.getElementById("departmentId");
const surName = document.getElementById("surNameInput");
const firstName = document.getElementById("firstNameInput");
const OtherName = document.getElementById("otherNameInput");
const staffId = document.getElementById("staffIdInput");
const statusInput = document.getElementById("status");

// // Add lecturer //
addForms.addEventListener("submit", (e) => {
  e.preventDefault();
  const submitForm = {
    DepartmentId: Number(departmentId.value),
    Surname: surName.value,
    FirstName: firstName.value,
    OtherNames: OtherName.value,
    StaffId: staffId.value,
    Status: Number(statusInput.value = statusInput.checked == true ? 1 : 0),
  };

  //--------Validating the Input --------//
  validate.userChoseOne(submitForm.DepartmentId, "Department");
  validate.length(submitForm.Surname, 3, 50, "Surname");
  validate.length(submitForm.FirstName, 3, 50, "FirstName");
  validate.length(submitForm.OtherNames, 3, 50, "OtherNames");
  validate.length(submitForm.StaffId, 3, 10, "Staff Id");

  //   Validating the before submiting to the DB //
  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    addForms.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
    return;
  } else {
    console.log("not working");
    axios
      .post(`${API_Url}/api/v1/lecturers/add`, submitForm)
      .then((response) => {
        window.location.reload();
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

//------------delete Lecturer--------//
function deleteLecturer(id) {
  //------ deleting  it from the Server by using the Id----//
  axios
    .delete(`${API_Url}/api/v1/lecturers/` + id)
    .then((res) => {
      window.location.reload();
    })
    .catch((err) => {
      console.log(err);
    });
}

//---------Edits Js-------------//
const departmentId_edit = document.getElementById("departmentId_edit");
const surName_edit = document.querySelector("#surName_edit");
const firstName_edit = document.querySelector("#firstName_edit");
const otherName_edit = document.querySelector("#otherName_edit");
const staffId_edit = document.querySelector("#staffId_edit");
const status_edit = document.querySelector("#status_edit");

const editLecturer = async (id) => {
  // --------finding the data that is equal to LecturerId----------------//
  const lecturer = data.find((lecturer) => lecturer.LecturerId === id);
  lecturerId = lecturer.LecturerId;

  //-------getting the department from the server and mapping it into a select tag-------------------//
  const departmentSelect = document.getElementById("departmentId_edit");
  let deptMap = deptData.map((item, index) => {
    return `<option value="${item.DepartmentId}">${item.Name}</option>`;
  });
  let allData = `<option value="">--Please-Select---</option>`;
  departmentSelect.innerHTML = allData + deptMap.join("");

  departmentId_edit.value = lecturer.DepartmentId;
  surName_edit.value = lecturer.Surname;
  firstName_edit.value = lecturer.FirstName;
  staffId_edit.value = lecturer.StaffId;
  status_edit.checked = lecturer.Status === 1 ? true: false;
};
editForms.addEventListener("submit", (e) => {
    e.preventDefault();
    // Object to send to the DB//
    const submitForm = {
      DepartmentId: Number(departmentId_edit.value),
      Surname: surName_edit.value,
      FirstName: firstName_edit.value,
      StaffId: staffId_edit.value,
      Status: Number(status_edit.checked = status_edit.checked === true ? 1 : 0),
    };
    

  //--------Validating the Input --------//
  validate.userChoseOne(submitForm.DepartmentId, "Department");
  validate.length(submitForm.Surname, 3, 50, "Surname");
  validate.length(submitForm.FirstName, 3, 50, "FirstName");
  validate.length(submitForm.StaffId,3, 10,  "Staff Id");

  //   Validating the before submiting to the DB //
  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    editForms.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
    return;
  } else {
    console.log("not working");
    axios
      .put(`${API_Url}/api/v1/lecturers`, submitForm)
      .then((response) => {
        window.location.reload();
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

//  Details JS  //
const departmentIdDetail = document.getElementById("departmentId_detail");
const surNameDetail = document.querySelector("#surName_detail");
const firstNameDetail = document.querySelector("#firstName_detail");
const otherNameDetail = document.querySelector("#otherName_detail");
const staffIdDetail = document.querySelector("#staffId_detail");
const statusDetail = document.querySelector("#status_detail");

const detailLecturer = async (id) =>{
  // --------finding the data that is equal to LecturerId----------------//
  const lecturer = data.find((lecturer) => lecturer.LecturerId === id);
  lecturerId = lecturer.LecturerId;

   // mapping the department data into the Select tag//
  const departmentSelect = document.getElementById("departmentId_detail");
  let deptMap = deptData.map((item, index) => {
    return `<option value="${item.DepartmentId}">${item.Name}</option>`;
  });
  departmentSelect.innerHTML = deptMap;

  
  departmentIdDetail.value = lecturer.DepartmentId;
  surNameDetail.value = lecturer.Surname;
  firstNameDetail.value = lecturer.FirstName;
  staffIdDetail.value = lecturer.StaffId;
  statusDetail.checked = lecturer.Status == 1 ? "Active" : "Inactive";
}
