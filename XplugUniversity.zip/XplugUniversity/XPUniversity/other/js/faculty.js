const addAllForm = document.getElementById("addAllForm");
const editAllForm = document.getElementById("editAllForm");
const detailForm = document.getElementById("detailForm");
const table = document.getElementById("table-body");
const validate = new Validate();
let facultyId;
let data;
const errDiv = document.createElement("div");
errDiv.className = "alert alert-danger";
const API_Url = "http://192.168.17.220:8097";

const facult = async () => {
  try {
    const response = await axios.get(`${API_Url}/api/v1/faculties`);
    data = response.data;

    data.forEach((faculty, id) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${id + 1}</td>
        <td>${faculty.Name}</td>
        <td>${faculty.UniqueId}</td>
        <td>${faculty.Code}</td>
        <td>${
          faculty.Status === 1
            ? '<div class="text-success">Active</div>'
            : '<div class="text-danger">Inactive<div>'
        }</td>
        <td>
          <button class="btn btn-success" data-toggle="modal" data-target="#editModal" aria-label="Close" onclick="editFaculty(${
            faculty.FacultyId
          })">Edit</button>
          <button class="btn btn-danger" onclick="deleteFaculty(${
            faculty.FacultyId
          })">Delete</button>
        </td>
      `;
      table.appendChild(row);
    });
  } catch (error) {
    console.log(error);
  }
};

document.addEventListener("DOMContentLoaded", facult);

//-----Add Faculties-----//
addAllForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const ALLData = new FormData(addAllForm);
  const info = Object.fromEntries(ALLData.entries());
  // validate checkbox
  if (info.Status) {
    info.Status = 1;
  } else {
    info.Status = 0;
  }

  //--------Validating the Input --------//
  validate.length(info.Name, 3, 50, "Name");
  validate.length(info.Code, 3, 10, "Code");
  validate.length(info.UniqueId, 3, 10, "UniqueId");

  //   Validating the before submiting to the DB //
  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    addAllForm.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
  } else {
    console.log("working");
    axios
      .post(`${API_Url}/api/v1/faculties/add`, info)
      .then((response) => {
        window.location.reload();
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

//------------delete Faculties--------//
function deleteFaculty(id) {
  //------ deleting  it from the Server by using the Id----//
  axios
    .delete(`${API_Url}/api/v1/faculties/` + id)
    .then((res) => {
      window.location.reload();
    })
    .catch((err) => {
      console.log(err);
    });
}

//-------Edit Faculties------//

const facultyNameEdit = document.getElementById("facultyName_edit");
const codeEdit = document.getElementById("code_edit");
const uniqueIdEdit = document.getElementById("uniqueId_edit");
const statusEdit = document.getElementById("status_edit");

const editFaculty = async (id) => {
  const faculty = data.find((faculty) => faculty.FacultyId === id);
  facultyId = faculty.FacultyId;

  facultyNameEdit.value = faculty.Name;
  codeEdit.value = faculty.Code;
  uniqueIdEdit.value = faculty.UniqueId;
  statusEdit.checked = faculty.Status == 1 ? true : false;
};

editAllForm.addEventListener("submit", (e) => {
  e.preventDefault();

  //----------Submit to the backend-------//
  const submitForm = {
    FacultyId: facultyId,
    Name: facultyNameEdit.value,
    Code: codeEdit.value,
    UniqueId: uniqueIdEdit.value,
    Status: Number((statusEdit.value = statusEdit.checked == true ? 1 : 0)),
  };

  // ----------Validations ----------//
  validate.length(submitForm.Name, 3, 50, "Name");
  validate.length(submitForm.Code, 3, 10, "Code");
  validate.length(submitForm.UniqueId, 3, 10, "Unique Id");

  // CHECK FOR ERROR BEFORE PUTING
  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    editAllForm.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
  } else {
    axios
      .put(`${API_Url}/api/v1/faculties`, submitForm)
      .then((result) => {
        window.location.reload();
      })
      .catch((err) => {
        console.log(err);
      });
  }
});
