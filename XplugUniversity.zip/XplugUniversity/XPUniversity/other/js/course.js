const addAllForm = document.getElementById("addAllForm");
const editModalForm = document.getElementById("editModalForm");
const detailsModalForm = document.getElementById("detailsModalForm");
const validate = new Validate();
const table = document.getElementById("table-body");
let courseId;
let data;
let deptData;
const API_Url = "http://192.168.17.220:8097";
const errDiv = document.createElement("div");
errDiv.className = "alert alert-danger";

const Course = async () => {
  try {
    // getting courses from the DB//
    const response = await axios.get(`${API_Url}/api/v1/courses`);
    data = response.data;
  // getting department from the DB//
    const resp = await axios.get(`${API_Url}/api/v1/departments`);
    deptData = resp.data;
    // mapping department into the select tag//
    const departmentSelect = document.getElementById("departmentId");
     let deptMap = deptData.map((item, index) => {
       return `<option value="${item.DepartmentId}">${item.Name}</option>`;
     });
     let allData = `<option value="">--Please-Select---</option>`;
     departmentSelect.innerHTML = allData + deptMap.join("");

    data.forEach((courses, id) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${id + 1}</td>
        <td>${courses.Name}</td>
        <td>${courses.UniqueId}</td>
        <td>${courses.Code}</td>
        <td>${
          courses.Status == 1
            ? '<div class="text-success">Active</div>'
            : '<div class="text-danger">Inactive<div>'
        }</td>
        <td>
          <button class="btn btn-success" data-toggle="modal" data-target="#editModal" aria-label="Close" onclick="editCourse(${
            courses.CourseId
          })">Edit</button>
          <button class="btn btn-danger" onclick="deleteCourses(${
            courses.CourseId
          })">Delete</button>
           <button class="btn btn-success" data-toggle="modal" data-target="#detailModal" aria-label="Close" onclick="detailCourse(${
             courses.CourseId
           })">Details</button>

        </td>
      `;
      table.appendChild(row);
    });
  } catch (error) {
    console.log(error);
  }
};

//--------------------delete Courses--------------------------//
function deleteCourses(id) {
  axios
    .delete(`${API_Url}/api/v1/courses/` + id)
    .then((res) => {
      window.location.reload();
    })
    .catch((err) => {
      console.log(err);
    });
}

document.addEventListener("DOMContentLoaded", Course);

addAllForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const departmentId = document.getElementById("departmentId");
  const name = document.getElementById("name");
  const code = document.getElementById("code");
  const uniqueId = document.getElementById("uniqueId");
  const units = document.getElementById("units");
  const courseLevel = document.getElementById("courseLevelInput");
  const courseSemester = document.getElementById("courseSemester");
  const status = document.getElementById("status");

  const submitForm = {
    DepartmentId: Number(departmentId.value),
    Name: name.value,
    Code: code.value,
    UniqueId: uniqueId.value,
    Units: Number(units.value),
    CourseLevel: Number(courseLevel.value),
    CourseSemester: Number(courseSemester.value),
    Status:Number(status.value = status.checked == true ? 1 : 0),
  };

  validate.userChoseOne(submitForm.DepartmentId, "Department");
  validate.length(submitForm.Name, 3, 50, "Name");
  validate.length(submitForm.Code, 3, 10, "Code");
  validate.length(submitForm.UniqueId, 3, 10, "Unique ID");
  validate.userChoseOne(submitForm.Units, "Units");
  validate.userChoseOne(submitForm.CourseLevel, "CourseLevel");
  validate.userChoseOne(submitForm.CourseSemester, "CourseSemester");

  // CHECK FOR ERROR BEFORE PUTING
  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    addAllForm.prepend(errDiv);
    // addAllForm.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
  } else {
    console.log("working");
    axios
      .post(`${API_Url}/api/v1/courses/add`, submitForm)
      .then((response) => {
        window.location.reload();
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

//---------------------------- Edit js---------------------------------//

// Getting the Input from the html with thier Id//
const departmentIdEdit = document.getElementById("departmentId_edit");
const nameEdit = document.getElementById("name_edit");
const codeEdit = document.getElementById("code_edit");
const uniqueIdEdit = document.getElementById("uniqueId_edit");
const unitEdit = document.getElementById("unit_edit");
const courseLevelEdit = document.getElementById("courseLevel_edit");
const courseSemesterEdit = document.getElementById("courseSemester_edit");
const statusEdit = document.getElementById("status_edit");

const editCourse = async (id) => {
  //------- Getting the course Id------//
  const course = data.find((course) => course.CourseId === id);
  courseId = course.CourseId;

  // mapping the department data into the Select tag//
  const departmentSelect = document.getElementById("departmentId_edit");
  let deptMap = deptData.map((item, index) => {
    return `<option value="${item.DepartmentId}">${item.Name}</option>`;
  });
  let allData = `<option value="0">--Please-Select---</option>`;
  departmentSelect.innerHTML = allData + deptMap.join("");

  departmentIdEdit.value = course.DepartmentId;
  nameEdit.value = course.Name;
  codeEdit.value = course.Code;
  uniqueIdEdit.value = course.UniqueId;
  unitEdit.value = course.Units;
  courseLevelEdit.value = course.CourseLevel;
  courseSemesterEdit.value = course.CourseSemester;
  statusEdit.checked = course.Status == 1 ? true : false;
};

editModalForm.addEventListener("submit", (e) => {
  e.preventDefault();

  //   // OBEJCT TO SEND TO DB
  const submitForm = {
    CourseId: courseId,
    DepartmentId: Number(departmentIdEdit.value),
    Name: nameEdit.value,
    Code: codeEdit.value,
    UniqueId: uniqueIdEdit.value,
    Units: Number(unitEdit.value),
    CourseLevel: Number(courseLevelEdit.value),
    CourseSemester: Number(courseSemesterEdit.value),
    Status: Number(statusEdit.checked = statusEdit.checked == true ? 1 : 0),
  };

  //validate the input//
  validate.userChoseOne(submitForm.DepartmentId, "Department");
  validate.length(submitForm.Name, 3, 50, "Name");
  validate.length(submitForm.Code, 3, 10, "Code");
  validate.length(submitForm.UniqueId, 3, 10, "Unique ID");
  validate.userChoseOne(submitForm.Units, "Units");
  validate.userChoseOne(submitForm.CourseLevel, "CourseLevel");
  validate.userChoseOne(submitForm.CourseSemester, "CourseSemester");

  // CHECK FOR ERROR BEFORE PUTING
  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    editModalForm.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
  } else {
    axios
      .put(`${API_Url}/api/v1/courses`, submitForm)
      .then((result) => {
        console.log(result);
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

// ---------------------------Details js--------------------------------//

const departmentIdDetail = document.getElementById("departmentId_details");
const nameDetail = document.getElementById("name_details");
const codeDetail = document.getElementById("code_details");
const uniqueIdDetail = document.getElementById("uniqueId_details");
const unitDetail = document.getElementById("unit_details");
const courseLevelDetail = document.getElementById("courseLevel_details");
const courseSemesterDetail = document.getElementById("courseSemester_details");
const statusDetail = document.getElementById("status_details");

const detailCourse = async (id) => {
  // --------Getting the course id --------//
  const course = data.find((course) => course.CourseId === id);
  courseId = course.CourseId;

   // mapping the department data into the Select tag//
  const departmentSelect = document.getElementById("departmentId_details");
  let deptMap = deptData.map((item, index) => {
    return `<option value="${item.DepartmentId}">${item.Name}</option>`;
  });
  departmentSelect.innerHTML = deptMap;

  departmentIdDetail.value = course.DepartmentId;
  nameDetail.value = course.Name;
  codeDetail.value = course.Code;
  uniqueIdDetail.value = course.UniqueId;
  unitDetail.value = course.Units;
  courseLevelDetail.value = course.CourseLevel;
  courseSemesterDetail.value = course.CourseSemester;
  statusDetail.value = course.Status == 1 ? "Active" : "Inactive";
};

// function validateCourse(course) {
//   validate.userChoseOne(course.DepartmentId, "Department");
//   validate.length(course.Name, 3, 50, "Name");
//   validate.length(course.UniqueId, 3, 10, "UniqueId");
//   validate.userChoseOne(course.Units, "Units");
//   validate.length(course.Code, 3, 10, "Code");
//   validate.userChoseOne(course.CourseLevel, "CourseLevel");
//   validate.userChoseOne(course.CourseSemester, "CourseSemester");

//   // CHECK FOR ERROR BEFORE PUTING
//   if (validate._errors.length > 0) {
//     const errDiv = document.createElement("div");
//     errDiv.className = "alert alert-danger";
//     errDiv.innerHTML = validate.errors[0];
//     AllForm.prepend(errDiv);
//     // addAllForm.prepend(errDiv);
//     setTimeout(() => {
//       errDiv.remove();
//     }, 3000);
//     return false;
//   }
//   return true;
// }
