const addAllForm = document.getElementById("addAllForm");
const editAllForm = document.getElementById("editAllForm");
const detailAllForm = document.getElementById("detailAllForm");
const validate = new Validate();
const table = document.getElementById("table-body");
let courseOfStudyId;
let data;
let deptData;
const API_Url = "http://192.168.17.220:8097";
const errDiv = document.createElement("div");
errDiv.className = "alert alert-danger";

//-----------Get the courseOfStudy --------//
const CoursesOfStudy = async () => {
  try {
    // getting Course Of study from DB
    const response = await axios.get(`${API_Url}/api/v1/coursesOfStudy`);
    data = response.data;

    // getting department from the DB//
    const resp = await axios.get(`${API_Url}/api/v1/departments`);
    deptData = resp.data;
    // mapping department into the select tag//
    const departmentSelect = document.getElementById("departmentId");
    let deptMap = deptData.map((item, index) => {
      return `<option value="${item.DepartmentId}">${item.Name}</option>`;
    });
    let allData = `<option value="">--Please-Select---</option>`;
    departmentSelect.innerHTML = allData + deptMap.join("");

    //----------Using the Data variables in an for each loop to populate the tables----------//
    data.forEach((courseOfStudy, id) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${id + 1}</td>
        <td>${courseOfStudy.Name}</td>
        <td>${courseOfStudy.ShortName}</td>
        <td>${courseOfStudy.UniqueId}</td>
        <td>${courseOfStudy.Award}</td>
        <td>${
          courseOfStudy.Status == 1
            ? '<div class="text-success">Active</div>'
            : '<div class="text-danger">Inactive<div>'
        }</td>
        <td>
          <button class="btn btn-success" data-toggle="modal" data-target="#editModal" aria-label="Close" onclick="editCourseOfStudy(${
            courseOfStudy.CourseOfStudyId
          })">Edit</button>
          <button class="btn btn-danger" onclick="deleteCourseOfStudy(${
            courseOfStudy.CourseOfStudyId
          })">Delete</button>
           <button class="btn btn-success" data-toggle="modal" data-target="#detailModal" aria-label="Close" onclick="detailCourseOfStudy(${
             courseOfStudy.CourseOfStudyId
           })">Details</button>

        </td>
      `;
      table.appendChild(row);
    });
  } catch (error) {
    console.log(error);
  }
};

document.addEventListener("DOMContentLoaded", CoursesOfStudy);

//-------------------- Add CourseOfStudy ------------------------//
addAllForm.addEventListener("submit", (e) => {
  //----Getting all the Input from the form in the html with thier Id------//
  e.preventDefault();
  const departmentId = document.getElementById("departmentId");
  const name = document.getElementById("name");
  const shortName = document.getElementById("shortName");
  const uniqueId = document.getElementById("uniqueId");
  const award = document.getElementById("award");
  const duration = document.getElementById("duration");
  const requiredCreditUnits = document.getElementById("requiredCreditUnits");
  const advisor = document.getElementById("advisor");
  const status_add = document.getElementById("status_add");

  //--------Submit the form to the server------------//
  const submitForm = {
    DepartmentId: Number(departmentId.value),
    Name: name.value,
    ShortName: shortName.value,
    UniqueId: uniqueId.value,
    Award: award.value,
    Duration: Number(duration.value),
    RequiredCreditUnits: Number(requiredCreditUnits.value),
    Advisor: advisor.value,
    Status: Number(status_add.value = status_add.checked == true ? 1 : 0),
  };
  
  //-------Validation of the form Input---------------//

  validate.userChoseOne(submitForm.DepartmentId, "Department");
  validate.length(submitForm.Name, 3, 50, "Name");
  validate.length(submitForm.ShortName, 3, 50, "ShortName");
  validate.length(submitForm.UniqueId, 3, 10, "UniqueId");
  validate.length(submitForm.Award, 3, 100, "Award");
  validate.userChoseOne(submitForm.Duration, "Duration");
  validate.userChoseOne(submitForm.RequiredCreditUnits, "RequiredCreditUnits");
  validate.length(submitForm.Advisor, 3, 50, "Advisor");

  //-----------------Validate the error
  if (validate._errors.length > 0) {
    console.log(validate._errors)
    errDiv.innerHTML = validate.errors[0];
    addAllForm.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
    // return
  } else {
    console.log(submitForm);
    axios
      .post(`${API_Url}/api/v1/coursesOfStudy/add`, submitForm)
      .then((response) => {
        window.location.reload();
    // $("#addModal").modal("hide");
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

//--------------------------Delete CourseOfStudy----------------//
function deleteCourseOfStudy(id) {
  //------ deleting  it from the Server by using the Id----//
  axios
    .delete(`${API_Url}/api/v1/coursesOfStudy/` + id)
    .then((res) => {
      window.location.reload();
    })
    .catch((err) => {
      console.log(err);
    });
}

//-----------Edits of CourseOfStudy----------------//

//----Getting all the Input from the form in the html with thier Id------//
const departmentIdEdit = document.getElementById("departmentId_edit");
const nameEdit = document.getElementById("name_edit");
const shortNameEdit = document.getElementById("shortName_edit");
const uniqueIdEdit = document.getElementById("uniqueId_edit");
const awardEdit = document.getElementById("award_edit");
const durationEdit = document.getElementById("duration_edit");
const requiredCreditUnitEdit = document.getElementById("requiredCreditUnit_edit");
const advisorEdit = document.getElementById("advisor_edit");
const statusEdit = document.getElementById("status_edit");

const editCourseOfStudy = async (id) => {
  // --------finding the data that is equal to courseOfStudyId----------------//
  const courseOfStudy = data.find(
    (courseOfStudy) => courseOfStudy.CourseOfStudyId === id
  );
  courseOfStudyId = courseOfStudy.CourseOfStudyId;

  //-------getting the department from the server and mapping it into a select tag-------------------//
  const departmentSelect = document.getElementById("departmentId_edit");
    let deptMap = deptData.map((item, index) => {
      return `<option value="${item.DepartmentId}">${item.Name}</option>`;
    });
    let allData = `<option value="">--Please-Select---</option>`;
    departmentSelect.innerHTML = allData + deptMap.join("");


  departmentIdEdit.value = courseOfStudy.DepartmentId;
  nameEdit.value = courseOfStudy.Name;
  shortNameEdit.value = courseOfStudy.ShortName;
  uniqueIdEdit.value = courseOfStudy.UniqueId;
  awardEdit.value = courseOfStudy.Award;
  durationEdit.value = courseOfStudy.Duration;
  requiredCreditUnitEdit.value = courseOfStudy.RequiredCreditUnits;
  advisorEdit.value = courseOfStudy.Advisor;
  statusEdit.checked = courseOfStudy.Status === 1 ? true : false;
  
};

editAllForm.addEventListener("submit", (e) => {
  e.preventDefault();
  // Object to send to the DB //
  const submitForm = {
    CourseOfStudyId: courseOfStudyId,
    DepartmentId: Number(departmentIdEdit.value),
    Name: nameEdit.value,
    ShortName: shortNameEdit.value,
    UniqueId: uniqueIdEdit.value,
    Award: awardEdit.value,
    Duration: Number(durationEdit.value),
    RequiredCreditUnits: Number(requiredCreditUnitEdit.value),
    Advisor: advisorEdit.value,
    Status: Number(statusEdit.checked = statusEdit.checked == true ? 1 : 0),
  };
    // Validating the Input//
  validate.userChoseOne(submitForm.DepartmentId, "Department");
  validate.length(submitForm.Name, 3, 50, "Name");
  validate.length(submitForm.ShortName, 3, 50, "ShortName");
  validate.length(submitForm.UniqueId, 3, 10, "UniqueId");
  validate.length(submitForm.Award, 3, 100, "Award");
  validate.userChoseOne(submitForm.Duration, "Duration");
  validate.userChoseOne(submitForm.RequiredCreditUnits, "RequiredCreditUnit");
  validate.length(submitForm.Advisor, 3, 50, "Advisor");

  // CHECK FOR ERROR BEFORE PUTING
  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    editAllForm.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
    // console.log(validate._errors);
  } else {
    axios
      .put(`${API_Url}/api/v1/coursesOfStudy`, submitForm)
      .then((result) => {
        window.location.reload();
        // $("#editModal").modal("hide");
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

//-----Details for courseOfStudy------------//

const departmentIdDetail = document.getElementById("departmentId_detail");
const nameDetail = document.getElementById("name_details");
const shortNameDetail = document.getElementById("shortName_detail");
const uniqueIdDetail = document.getElementById("uniqueId_detail");
const awardDetail = document.getElementById("award_detail");
const durationDetail = document.getElementById("duration_detail");
const requiredCreditUnitDetail = document.getElementById("requiredCreditUnit_detail");
const advisorDetail = document.getElementById("advisor_detail");
const statusDetail = document.getElementById("status_detail");

const detailCourseOfStudy = async (id) => {
  const courseOfStudy = data.find(
    (courseOfStudy) => courseOfStudy.CourseOfStudyId === id
  );
  courseOfStudyId = courseOfStudy.CourseOfStudyId;


  const departmentSelect = document.getElementById("departmentId_detail");
   let deptMap = deptData.map((item, index) => {
     return `<option value="${item.DepartmentId}">${item.Name}</option>`;
   });
   let allData = `<option value="">--Please-Select---</option>`;
   departmentSelect.innerHTML = allData + deptMap.join("");


  departmentIdDetail.value = courseOfStudy.DepartmentId;
  nameDetail.value = courseOfStudy.Name;
  shortNameDetail.value = courseOfStudy.ShortName;
  uniqueIdDetail.value = courseOfStudy.UniqueId;
  awardDetail.value = courseOfStudy.Award;
  durationDetail.value = courseOfStudy.Duration;
  requiredCreditUnitDetail.value = courseOfStudy.RequiredCreditUnits;
  advisorDetail.value = courseOfStudy.Advisor;
  statusDetail.value = courseOfStudy.Status == 1 ? "Active" : "Inactive";
}
