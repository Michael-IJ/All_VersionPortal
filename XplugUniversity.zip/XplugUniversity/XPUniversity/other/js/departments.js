const addForms = document.getElementById("addForms");
const editForms = document.getElementById("editForms");
const detailsForms = document.getElementById("detailsForms");
const API_Url = "http://192.168.17.220:8097";
const validate = new Validate();
let data;
let facultData;
let departmentId;

const errDiv = document.createElement("div");
errDiv.className = "alert alert-danger";

const Dept = async () => {
  try {
    const table = document.getElementById("table-body");
    const response = await axios.get(`${API_Url}/api/v1/departments`);
    data = response.data;

    const resp = await axios.get(`${API_Url}/api/v1/faculties`);
    facultData = resp.data;

    const facultySelect = document.getElementById("facultyId");
    let facultMap = facultData.map((item, index) => {
      return `<option value="${item.FacultyId}">${item.Name}</option>`;
    });
    let allData = '<option value="0">---Please Select---</option>';
    facultySelect.innerHTML = allData + facultMap.join("");

    data.forEach((departments, id) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${id + 1}</td>
        <td>${departments.Name}</td>
        <td>${departments.UniqueId}</td>
        <td>${departments.Code}</td>
        <td>${
          departments.Status == 1
            ? '<div class="text-success">Active</div>'
            : '<div class="text-danger">Inactive<div>'
        }</td>
        <td>
          <button class="btn btn-success " data-toggle="modal" data-target="#editModal" aria-label="Close" onclick="editDepartment(${
            departments.DepartmentId
          })">Edit</button>
          <button class="btn btn-danger" onclick="deletedepartments(${
            departments.DepartmentId
          })">Delete</button>
           <button class="btn btn-success" data-toggle="modal" data-target="#detailModal" aria-label="Close" onclick="detailDepartment(${
             departments.DepartmentId
           })">Details</button>

        </td>
      `;
      table.appendChild(row);
    });
  } catch (error) {
    console.log(error);
  }
};

document.addEventListener("DOMContentLoaded", Dept);

addForms.addEventListener("submit", (e) => {
  e.preventDefault();
  const formData = new FormData(addForms);
  const info = Object.fromEntries(formData.entries());
  // validate checkbox
  if (info.Status) {
    info.Status = 1;
  } else {
    info.Status = 0;
  }

  validate.length(info.Name, 3, 50, "Name");
  validate.userChoseOne(info.FacultyId, "Faculty");
  validate.length(info.UniqueId, 3, 10, "Unique Id");
  validate.length(info.Code, 3, 10, "Code");

  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    addForms.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
  } else {
    // console.log("not working");
    axios
      .post(`${API_Url}/api/v1/departments/add`, info)
      .then((response) => {
        window.location.reload();
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

//------------Delete Departments-----------------------------//
function deletedepartments(id) {
  axios
    .delete(`${API_Url}/api/v1/departments/` + id)
    .then((res) => {
      window.location.reload();
    })
    .catch((err) => {
      console.log(err);
    });
}

//------------------Edits Departments-------------------------//

const facultyIdInput = document.querySelector("#facultyIdInput");
const departmentNameInput = document.querySelector("#departmentNameInput");
const uniqueIdInput = document.querySelector("#uniqueIdInput");
const codeInput = document.querySelector("#codeInput");
const statusInput = document.querySelector("#statusInput");

const editDepartment = async (id) => {
  const department = data.find((department) => department.DepartmentId === id);
  departmentId = department.DepartmentId;

  const resp = await axios.get(`${API_Url}/api/v1/faculties`);
  dat = resp.data;

  const facultySelect = document.getElementById("facultyIdInput");
  let facultMap = facultData.map((item, index) => {
    return `<option value="${item.FacultyId}">${item.Name}</option>`;
  });
  let allData = '<option value="0">---Please Select---</option>';
  facultySelect.innerHTML = allData + facultMap.join("");

  facultyIdInput.value = department.FacultyId;
  departmentNameInput.value = department.Name;
  uniqueIdInput.value = department.UniqueId;
  codeInput.value = department.Code;
  statusInput.checked = department.Status === 1 ? true : false;
};

editForms.addEventListener("submit", (e) => {
  e.preventDefault();

  //-------- Submit to the backend-------------//
  const submitForm = {
    DepartmentId: departmentId,
    FacultyId: Number(facultyIdInput.value),
    Name: departmentNameInput.value,
    UniqueId: uniqueIdInput.value,
    Code: codeInput.value,
    Status: Number((statusInput.checked = statusInput.checked == true ? 1 : 0)),
  };

  // ------validation-----------------------//
  validate.userChoseOne(submitForm.FacultyId, "Faculty");
  validate.length(submitForm.Name, 3, 50, "Name");
  validate.length(submitForm.UniqueId, 3, 10, "Unique Id");
  validate.length(submitForm.Code, 3, 10, "Code");

  // CHECK FOR ERROR BEFORE PUTING
  if (validate._errors.length > 0) {
    errDiv.innerHTML = validate.errors[0];
    editForms.prepend(errDiv);
    setTimeout(() => {
      errDiv.remove();
    }, 3000);
  } else {
    axios
      .put(`${API_Url}/api/v1/departments`, submitForm)
      .then((result) => {
        window.location.reload();
      })
      .catch((err) => {
        console.log(err);
      });
  }
});

//----Details Department-----------------//

const facultyIdDetail = document.querySelector("#facultyId_detail");
const departmentNameDetail = document.querySelector("#departmentName_detail");
const uniqueIdDetail = document.querySelector("#uniqueId_detail");
const codeDetail = document.querySelector("#code_detail");
const statusDetail = document.querySelector("#status_detail");

const detailDepartment = async (id) => {
  const department = data.find((department) => department.DepartmentId === id);
  departmentId = department.DepartmentId;

  const resp = await axios.get(`${API_Url}/api/v1/faculties`);
  facultData = resp.data;

  const facultySelect = document.getElementById("facultyId_detail");
  let facultMap = facultData.map((item, index) => {
    return `<option value="${item.FacultyId}">${item.Name}</option>`;
  });
  

  facultySelect.innerHTML = facultMap;

  facultyIdDetail.value = department.FacultyId;
  departmentNameDetail.value = department.Name;
  uniqueIdDetail.value = department.UniqueId;
  codeDetail.value = department.Code;
  statusDetail.value = department.Status == 1 ? "Active" : "Inactive";
};
