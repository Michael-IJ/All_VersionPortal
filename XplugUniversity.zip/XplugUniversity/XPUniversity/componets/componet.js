function pageLoaded() {

    function loadSideBar() {
      const sideBar = document.getElementById("sideBar");
      const xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          sideBar.innerHTML = xhr.responseText;
        }
      };
      xhr.open("GET", "../componets/sideBar.html", true);
      xhr.send();
    }
    loadSideBar();

    function loadTopBar() {
      const topBar = document.getElementById("topBar");
      const xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          topBar.innerHTML = xhr.responseText;
        }
      };
      xhr.open("GET", "../componets/topBar.html", true);
      xhr.send();
    }

    loadTopBar();
    function loadFooter() {
      const footer = document.getElementById("footer");
      const xhr = new XMLHttpRequest();
      xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
          footer.innerHTML = xhr.responseText;
        }
      };
      xhr.open("GET", "../componets/footer.html", true);
      xhr.send();
    }
    loadFooter();




}
document.addEventListener("DOMContentLoaded", pageLoaded);