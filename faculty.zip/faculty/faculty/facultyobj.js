class FacultyObj{
    constructor(){
        this.FacultyId = 0;
        this.Name = "";
        this.UniqueId = "";
        this.Code = "";
        this.Status = 0;
    }
}

class FacultyFilterObj{
    constructor(){
        this.FacultyId = 0;
        this.Name = "";
        this.Status = 0;
    }
}