const db = require("./facultyDB");

class Faculty {
  getAllFaculties = async (req, res) => {
    console.log("Getting faculties")
    try {
      const retVal = await db.getFaculties();
      if (retVal == null) {
        res.status(400).json({ Error: "No faculties found" });
      }
      res.status(200).send(retVal);
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  getFaculty = async (req, res) => {
    try {
      const { facultyId } = req.params;
      console.log(facultyId);
      const retVal = await db.getFaculty(facultyId);
      if (retVal == null) {
        res.status(400).json({ Error: "No faculty found" });
      } else {
        res.status(200).send(retVal);
      }
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  getFaculties = async (req, res) => {
    try {
      const { Status, Name } = req.body;
      if (!Status && !Name) {
        return res.status(400).json({ Error: "Please input a valid query" });
      } else {
        const retVal = await db.getFacultiesByQuery(Status, Name);
        if (retVal == null) {
          res
            .status(400)
            .json({
              Error: db.getError() === null ? "No faculty found" : db.getError(),
            });
        } else {
          res.status(200).send(retVal);
        }
      }
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  addFaculty = async (req, res) => {
    try {
      const faculty = { ...req.body };
      if (!faculty) res.status(400).json({ Error: "Input Faculty Data" });

      //----------------------Validate API HERE ----------------------------------
      const validate = this.validate(faculty);
      if (validate !== null) {
        return res.status(400).json({ Error: validate });
      }
      
      await db.addFaculty(faculty);
      return res.status(200).json({ IsSuccess: true });
    
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  removeFaculty = async (req, res) => {
    try {
      const { facultyId } = req.params;
      if (facultyId == 0) {
        res.status(400).json({ Error: "Please input a valid faculty Id" });
      } else {
        console.log(facultyId);
        await db.removeFaculty(facultyId);
        res.status(200).json({ IsSuccessFul: true });
      }
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  editFaculty = async (req, res) => {
    try {
      const faculty = { ...req.body };

      const validate = this.validate(faculty);
      if (validate !== null) {
        return res.status(400).json({ Error: validate });
      }
       else {
        await db.editFaculty(faculty);
        res.status(200).json({ IsSuccessFul: true });
      }
    } catch (error) {
      res.status(400).json({ Error: error });
      console.log(error);
    }
  }

  validate = (faculty) => {
    if (!faculty) return "Input Faculty Data";
    if (faculty.FacultyId ) {
      if (faculty.FacultyId < 1)
      return  "Invalid/Missing facultyId";
    } 
    if (!faculty.Name || faculty.Name === "" || faculty.Name.length < 3) {
      return "Invalid/Empty faculty name";
    }
    if (!faculty.UniqueID || faculty.UniqueID === "") {
      return "Invalid/Missing UniqueId";
    }
    if (!faculty.Code || faculty.Code === "") {
      return "Invalid/Missing code";
    }
    if (!faculty.Status || faculty.Status === 0) {
      return "Invalid/Missing status";
    }
    return null;
  }
}

module.exports = new Faculty;
