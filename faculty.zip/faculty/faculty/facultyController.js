var faculty = require("./faculty");
const express = require("express");
const router = express.Router();

class FacultyController {
  constructor(app) {
    router.get("/", faculty.getAllFaculties);
    router.get("/:facultyId", faculty.getFaculty);
    router.post("/", faculty.getFaculties);
    router.post("/add", faculty.addFaculty);
    router.put("/", faculty.editFaculty);
    router.delete("/:facultyId", faculty.removeFaculty);
    app.use("/api/v1/faculties", router);
  }
}

module.exports = FacultyController;
